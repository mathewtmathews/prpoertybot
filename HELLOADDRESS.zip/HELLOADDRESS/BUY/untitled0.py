# -*- coding: utf-8 -*-
"""
Created on Sat Mar 16 17:45:51 2019

@author: Aida
"""


import pymysql.cursors

#import re

    
connection = pymysql.connect(host='localhost',
                             user='root',
                             password='root',
                             db='REALESTATE',
                             charset='utf8mb4',
                             cursorclass=pymysql.cursors.DictCursor)
 
try:
    with connection.cursor() as cursor:        
        sql = "INSERT INTO `buykerala`  VALUES (3,'','','')"
        cursor.execute(sql)
    connection.commit()
finally:
    connection.close()