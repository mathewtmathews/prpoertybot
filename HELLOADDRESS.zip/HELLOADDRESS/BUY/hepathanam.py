from bs4 import BeautifulSoup as soup
from urllib.request import urlopen as uReg
import os
#import re
if os.path.exists('hepathanam.csv'):
    os.remove('hepathanam.csv')
    print("file removed")
f = open('hepatanam.csv',"w",encoding='utf-8')
headers = "Name,Location,City,District,Price,Bed,PropertyID,PropertyArea,OwnershipType,image\n"
f.write(headers)

sam_url= "https://www.helloaddress.com/search/list?propertyAction=S&propertyType=RA&districtId=4&townId=51&l_src=home_top_banner"
name=''
image = ''
loc=''
city=''
district=''
price=''
bed=''
propertyID=''
PropertyArea=''
OwnershipType=''
i=1

#for j in range(0, 15):
for i in range(0, 100):
    uClient_=uReg(sam_url)
    page_html_=uClient_.read()
    uClient_.close()
    page_soup_= soup(page_html_,"html.parser")
    containers_= page_soup_.find_all("div",attrs={"class":"list-block"})
    container_=containers_[0]
    sam_url="https://www.helloaddress.com/search/list?page="+str(i+1)+"&propertyAction=S&propertyType=RA%2CRH%2CRL%2CRO%2CCS%2CCF%2CCL%2CCB%2CCO%2CIB%2CIL%2CAL&districtId=4&l_src=home_top_banner"
    for container_ in containers_:
        for img in container_.findAll("div",attrs={"class":"img-wrap"}):
            image = img['data-original-src'].strip()
            print (image)
                #property_name=container_.div.img["alt"]
        mainnamecontainer=container_.find_all("div",attrs={"class":"list-details"})
        if len(mainnamecontainer)>0:
           namecontainer=mainnamecontainer[0].find_all('a')
           if len(namecontainer)>0:
              name=namecontainer[0].text.strip()
              print(name)
           locationcontainer=container_.find_all('span',{'class':'font-roboto light'})
           if len(locationcontainer)>0:
                location=locationcontainer[0].text.strip()
                x = location.split(", ")
                loc=x[len(x)-3]
                city=x[len(x)-2]
                district=x[len(x)-1]
                print(location)
                print(loc)
                print(city)
                print(district)
           pricecontainer=container_.find_all('h3',{'class':'font-nunito'})
           if len(pricecontainer)>0:
                spancontainer = pricecontainer[0].find_all('span')
                span_value =''
                if len(spancontainer)>0:
                    span_value = spancontainer[0].text.strip()
                    price=pricecontainer[0].text.strip()
                    price=price.replace(span_value,'')
                print(price)
           bedcontainer=container_.find_all('li',{'class':'bed'})
           if len(bedcontainer)>0:
                bed=bedcontainer[0].text.strip()
                bed=bed.replace(' Bed','')
                bed=bed.replace(' room','')
                print(bed)
           detailscontainer=container_.find_all('div',{'class':'col-lg-7'})
           if len(detailscontainer)>0:
                details = detailscontainer[0].find_all('li')
                if len(details)>0:
                    propertyID=details[0].text.strip()
                    propertyID=propertyID.replace('Property ID : ','')
                    PropertyArea=details[1].text.strip()
                    PropertyArea=PropertyArea.replace('Property Area : ','')
                    OwnershipType=details[2].text.strip()
                    OwnershipType=OwnershipType.replace('Ownership Type : ','')
                    print('main details:' +propertyID,PropertyArea,OwnershipType)
          
            
        
           f.write(name +  ',' + loc + ',' + city + ',' + district + ',' + price + ',' + bed + ',' +propertyID + ',' + PropertyArea + ',' + OwnershipType +  ',' + image + "\n")

    print(sam_url )
    i=i+1
   # j=j+1
   # print(j)
f.close()


